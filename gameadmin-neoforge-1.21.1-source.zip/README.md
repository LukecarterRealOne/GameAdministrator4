# Game Administrator (NeoForge 1.21.1)

Press **G** for the Admin Console (17 abilities, Powers tab, Passives tab). **V** repeats your last ability, **H** toggles flight.
Abilities hit every living thing near you except yourself. World VFX (rings, beams, bubbles, black hole) are server-side so
everyone sees them. No particles. If world effects do not appear, search `logs/latest.log` for `Command rejected by the parser`.

Time Stop uses the real `/tick freeze` (8 seconds). Game rules use the camelCase names of 1.21.1.
Dedicated servers: only names in `config/gameadmin-admins.txt` can use the powers. Single player / LAN: everyone.

## Install
Minecraft **1.21.1**, **NeoForge 21.1+**, Java 21. Put the jar in `mods/`.

## Build on GitHub
Upload to a NEW repo. Actions tab -> "Build mod" -> download the `gameadmin-1.21.1-neoforge` artifact.
