package com.gameadmin.mod;

import net.neoforged.fml.loading.FMLPaths;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Who may use the admin powers?
 * - Single player / opened-to-LAN worlds: everyone in the world.
 * - Dedicated servers: only names listed in config/gameadmin-admins.txt (one name per line).
 */
public final class Gate {
    private Gate() {}

    private static Set<String> admins = new HashSet<>();
    private static long lastLoad = 0;

    public static MinecraftServer server(ServerPlayer player) {
        return player.level() instanceof ServerLevel level ? level.getServer() : null;
    }

    public static boolean allowed(ServerPlayer player, MinecraftServer server) {
        if (!server.isDedicatedServer()) return true;
        return loadAdmins().contains(player.getScoreboardName().toLowerCase(Locale.ROOT));
    }

    public static void notice(ServerPlayer player, String text, int rgb) {
        Net.send(player, new Net.Notice(text, rgb));
    }

    public static void deny(ServerPlayer player) {
        notice(player, "Admins only (see config/gameadmin-admins.txt)", 0xFF5555);
    }

    private static Set<String> loadAdmins() {
        long now = System.currentTimeMillis();
        if (now - lastLoad < 5_000) return admins;
        lastLoad = now;
        Path file = FMLPaths.CONFIGDIR.get().resolve("gameadmin-admins.txt");
        try {
            if (!Files.exists(file)) {
                Files.writeString(file, "# Game Administrator: one player name per line. Only these players can use the mod's powers.\n");
            }
            Set<String> out = new HashSet<>();
            List<String> lines = Files.readAllLines(file);
            for (String line : lines) {
                String t = line.trim();
                if (t.isEmpty() || t.startsWith("#")) continue;
                out.add(t.toLowerCase(Locale.ROOT));
            }
            admins = out;
        } catch (IOException ex) {
            GameAdminMod.LOGGER.warn("Could not read admin list", ex);
        }
        return admins;
    }
}
